# Deepin desktop schemas

## Required by

* dde-api
* dde-daemon
* dde-workspace
* deepin-metacity
* deepin-mutter
* startdde
